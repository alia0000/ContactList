package com.test.contact.api.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.test.contact.api.model.Contacts;

import org.hibernate.query.Query;

public class ContactDaoImpl extends DaoBase implements ContactDao{
	
	@Override
	public List<Contacts> getAllContacts(){
	openSession(false);

	CriteriaBuilder builder = getCurrentSession().getCriteriaBuilder();
	CriteriaQuery<Contacts> query = builder.createQuery(Contacts.class);
	Root<Contacts> root = query.from(Contacts.class);
	query.select(root);
	Query<Contacts> q = getCurrentSession().createQuery(query);
	List<Contacts> result = q.getResultList();
	 
	 closeSession();
	 return result;
}
	
	@Override
	public void updateContacts(Contacts contacts) {
		openSession(true);
		getCurrentSession().update(contacts);
		commit();
		closeSession();		
	}

	@Override
	public void deleteContacts(Contacts contacts) {
		openSession(true);
		getCurrentSession().remove(contacts);
		commit();
		closeSession();		
	}

	@Override
	public void addContacts(Contacts contacts) {
		openSession(true);
		getCurrentSession().save(contacts);
		commit();
		closeSession();	
	}

	@Override
	public Contacts getId(int id) {
		openSession(false);
		Contacts contact = getCurrentSession().get(Contacts.class, id);
		closeSession();
		return contact;
	}



}
