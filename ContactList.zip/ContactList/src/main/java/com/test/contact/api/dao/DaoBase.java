package com.test.contact.api.dao;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.Transaction;

public class DaoBase {
	
	private Session session;
	private Transaction transaction;
	
	private static SessionFactory factory;
	
	public Session openSession(boolean requireTrans) {
		session = factory.openSession();
		if (requireTrans) {
			transaction = session.beginTransaction();
		}
		return session;
	}
	
	public void closeSession() {
		session.close();
	}
	
	public void commit() {
		if (transaction != null) {
			transaction.commit();
		}
	}
	
	public void rollbacl() {
		if (transaction != null) {
			transaction.rollback();
		}
	}
	
	public Session getCurrentSession() {
		return session;
	}
	
	public static void closeFactory() {
		factory.close();
	}
	
	static {
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();

		factory = meta.getSessionFactoryBuilder().build();
	}
}