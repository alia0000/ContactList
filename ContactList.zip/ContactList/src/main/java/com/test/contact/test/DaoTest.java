package com.test.contact.test;

import com.test.contact.api.dao.ContactDao;
import com.test.contact.api.dao.ContactDaoImpl;
import com.test.contact.api.dao.DaoBase;
import com.test.contact.api.model.Contacts;

import java.util.Date;
import java.util.List;

public class DaoTest {
	public static void main(String[] args) {
		ContactDao contactDao = new ContactDaoImpl();
		
		List<Contacts> contactsList = contactDao.getAllContacts();
		System.out.print(contactsList);
		
		
		
		Contacts contacts = contactDao.getId(1);
		
		contacts.setFname("Alia");
		contacts.setBirthday(new Date());
		contacts.setEmail("aliaalmualla@email.com");
		contacts.setLname("Almualla");		
		
		contactDao.updateContacts(contacts);
	
	
				
				DaoBase.closeFactory();
		
	}
}
