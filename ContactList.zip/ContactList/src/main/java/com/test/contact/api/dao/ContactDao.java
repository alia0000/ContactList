package com.test.contact.api.dao;
import java.util.List;
import com.test.contact.api.model.Contacts;

public interface ContactDao {
		public List<Contacts> getAllContacts();

		public void updateContacts(Contacts contacts);

		public void deleteContacts(Contacts contacts);

		public void addContacts(Contacts contacts);
		
		
		public Contacts getId(int id);
		

	}

