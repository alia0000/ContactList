package com.test.contact.test;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import com.test.contact.api.model.Contacts;

@WebService
public interface ContactsService {

	
	@WebMethod
	public Contacts getContacts(@WebParam(name="id") int id);
	
}
