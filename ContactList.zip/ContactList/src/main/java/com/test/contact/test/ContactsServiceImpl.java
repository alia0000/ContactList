package com.test.contact.test;

import javax.jws.WebService;

import com.test.contact.api.dao.ContactDao;
import com.test.contact.api.dao.ContactDaoImpl;
import com.test.contact.api.model.Contacts;

@WebService(endpointInterface = "com.test.contact.test.ContactsService")
public class ContactsServiceImpl {

	public Contacts getContacts(int id) {
		ContactDao contactDao = new ContactDaoImpl();
		return contactDao.getId(id);

	}

}