package com.test.contact.api.resource;

import javax.ws.rs.*;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.test.contact.api.model.ContactsRequest;
import com.test.contact.api.model.ContactsResponse;

@Path("/contacts")
public class ContactResource {
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ContactsResponse getContact(@QueryParam("id") int id) {
		ContactsResponse resp = new ContactsResponse();
		resp.setMessage(String.format("Hello [%s] From REST :)", id));

		return resp;

	}
}
