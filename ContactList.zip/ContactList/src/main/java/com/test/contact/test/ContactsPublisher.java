package com.test.contact.test;

import javax.xml.ws.Endpoint;


public class ContactsPublisher {

	public static void main(String[] args) {
		Endpoint.publish("http://localhost:8888/ws/contacts", new ContactsServiceImpl());
	}
}
