package com.test.contact.api.model;

import java.util.Date;

public class Contacts {

	private int id;
	private String fname;
	private String lname;
	private String mobileNum;
	private String homeNum;
	private String email;
	private Date birthday;

	public Contacts() {

	}

	public Contacts(String string, int i) {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public String getHomeNum() {
		return homeNum;
	}

	public void setHomeNum(String homeNum) {
		this.homeNum = homeNum;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	@Override
	public String toString() {
		return String.format("Contacts [id=%s, fname=%s, lname=%s, mobileNum=%s, homeNum=%s, email=%s, birthday=%s]",
				id, fname, lname, mobileNum, homeNum, email, birthday);
	}

}
